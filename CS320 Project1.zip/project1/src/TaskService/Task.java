//Author Name: Jian Wang

//Date: 06/13/2025

//Course ID: CS320

//Description: Task.java

package TaskService;

import java.util.concurrent.atomic.AtomicLong;

public class Task {
  private static final AtomicLong idGenerator = new AtomicLong();
  private final String taskID;
  private String taskName;
  private String taskDesc;

  public Task(String name, String description) {
      this.taskID = generateTaskID();
      setTaskName(name);
      setTaskDesc(description);
  }

  private String generateTaskID() {
      return String.format("%010d", idGenerator.getAndIncrement());
  }

  public String getTaskID() {
      return taskID;
  }

  public String getTaskName() {
      return taskName;
  }

  public void setTaskName(String name) {
      if (name == null || name.isEmpty()) {
          this.taskName = "NULL";
      } else if (name.length() > 20) {
          this.taskName = name.substring(0, 20);
      } else {
          this.taskName = name;
      }
  }

  public String getTaskDesc() {
      return taskDesc;
  }

  public void setTaskDesc(String description) {
      if (description == null || description.isEmpty()) {
          this.taskDesc = "NULL";
      } else if (description.length() > 50) {
          this.taskDesc = description.substring(0, 50);
      } else {
          this.taskDesc = description;
      }
  }
}
