//Author Name: Jian Wang

//Date: 06/13/2025

//Course ID: CS320

//Description: TaskServiceTest.java

package TaskService;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import TaskService.Task;
import TaskService.TaskService;

public class TaskServiceTest {

  @Test
  public void testAddTask() {
      TaskService service = new TaskService();
      service.addTask("Task Name", "Task Description");
      assertEquals(1, service.taskList.size());
      Task addedTask = service.taskList.get(0);
      assertEquals("Task Name", addedTask.getTaskName());
      assertEquals("Task Description", addedTask.getTaskDesc());
  }

  @Test
  public void testDeleteTask() {
      TaskService service = new TaskService();
      service.addTask("Task1", "Description1");
      String id = service.taskList.get(0).getTaskID();
      service.deleteTask(id);
      assertEquals(0, service.taskList.size());
  }

  @Test
  public void testUpdateTaskName() {
      TaskService service = new TaskService();
      service.addTask("Original Name", "Description");
      String id = service.taskList.get(0).getTaskID();
      service.updateTaskName("Updated Name", id);
      assertEquals("Updated Name", service.taskList.get(0).getTaskName());
  }

  @Test
  public void testUpdateTaskDescription() {
      TaskService service = new TaskService();
      service.addTask("Name", "Original Description");
      String id = service.taskList.get(0).getTaskID();
      service.updateTaskDesc("Updated Description", id);
      assertEquals("Updated Description", service.taskList.get(0).getTaskDesc());
  }
} 
