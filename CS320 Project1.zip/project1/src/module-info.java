/**
 * 
 */
/**
 * 
 */
module project1 {
	requires org.junit.jupiter.api;
}