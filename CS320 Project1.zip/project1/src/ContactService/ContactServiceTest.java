//Author Name: Jian Wang

//Date: 06/13/2025

//Course ID: CS320

//Description: ContactServiceTest class
package ContactService;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;

import ContactService.Contact;
import ContactService.ContactService;

import org.junit.jupiter.api.Order;

@TestMethodOrder(OrderAnnotation.class)
public class ContactServiceTest {
	
	@Test
	@DisplayName("Test to Update First Name.")
	@Order(1)
	void testUpdateFirstName() {
        ContactService service = new ContactService();
        service.addContact("Elon", "Musk", "1111111111", "12345 main street");
        String contactId = service.getContactList().get(0).getContactID();
        service.updateFirstName("Tesla", contactId);
        assertEquals("Tesla", service.getContact(contactId).getFirstName(), "First name was not updated.");
    }

	@Test
	@DisplayName("Test to Update Last Name.")
	@Order(2)
	void testUpdateLastName() {
        ContactService service = new ContactService();
        service.addContact("Elon", "Musk", "1111111111", "12345 main street");
        String contactId = service.getContactList().get(0).getContactID();
        service.updateLastName("ModelY", contactId);
        assertEquals("ModelY", service.getContact(contactId).getLastName(), "Last name was not updated.");
    }

	@Test
	@DisplayName("Test to update phone number.")
	@Order(3)
	void testUpdateNumber() {
        ContactService service = new ContactService();
        service.addContact("Elon", "Musk", "1111111111", "12345 main street");
        String contactId = service.getContactList().get(0).getContactID();
        service.updateNumber("2222222222", contactId);
        assertEquals("2222222222", service.getContact(contactId).getNumber(), "Phone number was not updated.");
    }

	@Test
	@DisplayName("Test to update address.")
	@Order(4)
	void testUpdateAddress() {
        ContactService service = new ContactService();
        service.addContact("Elon", "Musk", "1111111111", "12345 main street");
        String contactId = service.getContactList().get(0).getContactID();
        service.updateAddress("54321 main street", contactId);
        assertEquals("54321 main street", service.getContact(contactId).getAddress(), "Address was not updated.");
    }

	@Test
	@DisplayName("Test to ensure that service correctly deletes contacts.")
	@Order(5)
	void testDeleteContact() {
        ContactService service = new ContactService();
        service.addContact("Elon", "Musk", "1111111111", "12345 main street");
        String contactId = service.getContactList().get(0).getContactID();
        service.deleteContact(contactId);
        assertThrows(IllegalArgumentException.class, () -> service.getContact(contactId), "The contact was not deleted.");
    }

	@Test
	@DisplayName("Test to ensure that service can add a contact.")
	@Order(6)
	void testAddContact() {
        ContactService service = new ContactService();
        service.addContact("Elon", "Musk", "1111111111", "12345 main street");
        String contactId = service.getContactList().get(0).getContactID();
        assertNotNull(service.getContact(contactId), "Contact was not added correctly.");
    }

}