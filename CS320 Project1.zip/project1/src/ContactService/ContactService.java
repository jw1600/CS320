//Author Name: Jian Wang

//Date: 06/13/2025

//Course ID: CS320

//Description: ContactService class
package ContactService;

import java.util.ArrayList;

public class ContactService {
    public ArrayList<Contact> contactList = new ArrayList<Contact>();

    public ArrayList<Contact> getContactList() {
        return contactList;
    }

    public Contact getContact(String contactID) {
        for (Contact contact : contactList) {
            if (contact.getContactID().equals(contactID)) {
                return contact;
            }
        }
        throw new IllegalArgumentException("Contact ID: " + contactID + " not found.");
    }

    public void updateNumber(String updatedString, String contactID) {
        for (Contact contact : contactList) {
            if (contact.getContactID().equals(contactID)) {
                contact.setNumber(updatedString);
                return;
            }
        }
        throw new IllegalArgumentException("Contact ID: " + contactID + " not found.");
    }

    public void updateFirstName(String updatedString, String contactID) {
        for (Contact contact : contactList) {
            if (contact.getContactID().equals(contactID)) {
                contact.setFirstName(updatedString);
                return;
            }
        }
        throw new IllegalArgumentException("Contact ID: " + contactID + " not found.");
    }

    public void updateLastName(String updatedString, String contactID) {
        for (Contact contact : contactList) {
            if (contact.getContactID().equals(contactID)) {
                contact.setLastName(updatedString);
                return;
            }
        }
        throw new IllegalArgumentException("Contact ID: " + contactID + " not found.");
    }

    public void updateAddress(String updatedString, String contactID) {
        for (Contact contact : contactList) {
            if (contact.getContactID().equals(contactID)) {
                contact.setAddress(updatedString);
                return;
            }
        }
        throw new IllegalArgumentException("Contact ID: " + contactID + " not found.");
    }

    public void deleteContact(String contactID) {
        for (int counter = 0; counter < contactList.size(); counter++) {
            if (contactList.get(counter).getContactID().equals(contactID)) {
                contactList.remove(counter);
                return;
            }
        }
        throw new IllegalArgumentException("Contact ID: " + contactID + " not found.");
    }

    public void addContact(String firstName, String lastName, String number, String address) {
        Contact contact = new Contact(firstName, lastName, number, address);
        contactList.add(contact);
    }

    public void displayContactList() {
        for (Contact contact : contactList) {
            System.out.println("\t Contact ID: " + contact.getContactID());
            System.out.println("\t First Name: " + contact.getFirstName());
            System.out.println("\t Last Name: " + contact.getLastName());
            System.out.println("\t Phone Number: " + contact.getNumber());
            System.out.println("\t Address: " + contact.getAddress() + "\n");
        }
    }
}