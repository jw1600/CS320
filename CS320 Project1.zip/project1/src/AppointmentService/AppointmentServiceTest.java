//Author Name: Jian Wang

//Date: 06/13/2025

//Course ID: CS320

//Description: AppointmentServiceTest class

package AppointmentService;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;

import AppointmentService.Appointment;
import AppointmentService.AppointmentService;

class AppointmentServiceTest {
	private Date createDate(int year, int month, int day) {
		Calendar calendar = Calendar.getInstance();
		calendar.set(year, month, day);
		return calendar.getTime();
	}
	
	@Test
	@DisplayName("Test to Update appointment date")
	@Order(1)
	void testUpdateAppointmentDate() {
		AppointmentService service = new AppointmentService();
		service.addAppointment(createDate(2025, Calendar.JULY, 1), "Description");
		String appointmentId = service.appointmentList.get(0).getAppointmentID();
		service.updateAppointmentDate(createDate(2026, Calendar.FEBRUARY, 2), appointmentId);
		assertEquals(createDate(2026, Calendar.FEBRUARY, 2), service.getAppointment(appointmentId).getAppointmentDate(), "Appointment date was not updated.");
	}

	@Test
	@DisplayName("Test to Update appointment description.")
	@Order(2)
	void testUpdateAppointmentDesc() {
		AppointmentService service = new AppointmentService();
		service.addAppointment(createDate(2025, Calendar.JULY, 1), "Description");
		String appointmentId = service.appointmentList.get(0).getAppointmentID();
		service.updateAppointmentDesc("Updated Description", appointmentId);
		assertEquals("Updated Description", service.getAppointment(appointmentId).getAppointmentDesc(), "Appointment description was not updated.");
	}

	@Test
	@DisplayName("Test to ensure that service correctly deletes appointments.")
	@Order(3)
	void testDeleteAppointment() {
		AppointmentService service = new AppointmentService();
		service.addAppointment(createDate(2025, Calendar.JULY, 1), "Description");
		String appointmentId = service.appointmentList.get(0).getAppointmentID();
		service.deleteAppointment(appointmentId);
		ArrayList<Appointment> appointmentListEmpty = new ArrayList<Appointment>();
		assertEquals(service.appointmentList, appointmentListEmpty, "The appointment was not deleted.");
	}

	@Test
	@DisplayName("Test to ensure that service can add an appointment.")
	@Order(4)
	void testAddAppointment() {
		AppointmentService service = new AppointmentService();
		service.addAppointment(createDate(2025, Calendar.JULY, 1), "Description");
		String appointmentId = service.appointmentList.get(0).getAppointmentID();
		assertNotNull(service.getAppointment(appointmentId), "Appointment was not added correctly.");
	}
}